/*
 * selectable_core.js
 */
