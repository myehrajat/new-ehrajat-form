JalaliJSCalendar v1.4
-------------------
  Author: Ali Farhadi (http://farhadi.ir/)
  Released under the terms of the GNU Public License.
  See the GPL for details (http://www.gnu.org/licenses/gpl.html).

Based on The DHTML Calendar
-------------------
  Author: Mihai Bazon, <mihai_bazon@yahoo.com>
          http://dynarch.com/mishoo/

Contents
---------

  calendar.js       -- the main program file
  calendar-setup.js -- calendar setup script
  jalali.js         -- jalali extensions for Date Object
  lang/*.js         -- internalization files
  skins/            -- color themes
  examples/         -- example usage files
  doc/              -- documentation, in PDF and HTML
